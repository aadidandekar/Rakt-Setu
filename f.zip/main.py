#!/usr/bin/env python3
"""
RAKT-SETU P3 Integration Engineer - Complete Data Pipeline
Implements scheduled sync, SMS alerts, Firestore CRUD, predictive triggers, and offline fallback
"""

import os
import json
import time
import logging
import schedule
import requests
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
import hashlib

# Firebase & Google Cloud
import firebase_admin
from firebase_admin import credentials, db, firestore, messaging

# Twilio
from twilio.rest import Client

# Data processing
import csv

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ============================================================================
# CONFIGURATION & CREDENTIALS
# ============================================================================

FIREBASE_CONFIG = {
    "apiKey": "AIzaSyClqb7F7u0_eIBTKZ--zSm0qZCjAStBWPI",
    "authDomain": "blood-bank-401718.firebaseapp.com",
    "databaseURL": "https://blood-bank-401718-default-rtdb.firebaseio.com",
    "projectId": "blood-bank-401718",
    "storageBucket": "blood-bank-401718.firebasestorage.app",
    "messagingSenderId": "517187399539",
    "appId": "1:517187399539:web:c5855d0d79fc6363fe1f06"
}

TWILIO_CONFIG = {
    "account_sid": "AC9115df704d3ee832fe76947677d7d1a5",
    "auth_token": "efe4fd9b953b85e7cdac3a90d7f4500f",
    "from_number": "+1234567890",  # TODO: Replace with your Twilio number (e.g., "+919876543210")
}

# NBTC Data source (National Blood Transfusion Council - India)
NBTC_DATA_URL = "https://nbtc.gov.in/content/dam/nbtcindia/files/Stat_Reports/annual_statistical_report.csv"

# Local SQLite database for offline mode
OFFLINE_DB = "blood_bank_offline.db"

# ============================================================================
# DATA MODELS
# ============================================================================

@dataclass
class BloodInventory:
    blood_type: str
    quantity: int
    last_updated: str
    bank_id: str
    expiry_date: str
    
    def to_dict(self):
        return asdict(self)

@dataclass
class DonationRequest:
    request_id: str
    patient_blood_type: str
    quantity: int
    hospital_id: str
    urgency: str  # CRITICAL, HIGH, NORMAL
    timestamp: str
    status: str  # PENDING, MATCHED, COMPLETED

@dataclass
class DonorProfile:
    donor_id: str
    name: str
    blood_type: str
    phone: str
    last_donation: str
    donation_count: int
    location: str
    is_active: bool

# ============================================================================
# FIREBASE INITIALIZATION
# ============================================================================

def initialize_firebase():
    """Initialize Firebase with service account"""
    try:
        if not firebase_admin._apps:
            # Use default credentials (will look for GOOGLE_APPLICATION_CREDENTIALS env var)
            # For local testing, you can use the config dict
            firebase_admin.initialize_app(options=FIREBASE_CONFIG)
        logger.info("✅ Firebase initialized successfully")
        return True
    except Exception as e:
        logger.error(f"❌ Firebase initialization failed: {e}")
        return False

# ============================================================================
# FIRESTORE OPERATIONS - Donor Registry Backend
# ============================================================================

class FirestoreBackend:
    """Firestore CRUD + Search API for donor registry"""
    
    def __init__(self):
        self.db = firestore.client()
        self.collection = "donors"
    
    def create_donor(self, donor: DonorProfile) -> bool:
        """Create new donor profile"""
        try:
            self.db.collection(self.collection).document(donor.donor_id).set(
                donor.to_dict()
            )
            logger.info(f"✅ Donor created: {donor.donor_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Error creating donor: {e}")
            return False
    
    def read_donor(self, donor_id: str) -> Optional[DonorProfile]:
        """Read donor profile"""
        try:
            doc = self.db.collection(self.collection).document(donor_id).get()
            if doc.exists:
                data = doc.to_dict()
                return DonorProfile(**data)
            return None
        except Exception as e:
            logger.error(f"❌ Error reading donor: {e}")
            return None
    
    def update_donor(self, donor_id: str, updates: Dict) -> bool:
        """Update donor profile"""
        try:
            self.db.collection(self.collection).document(donor_id).update(updates)
            logger.info(f"✅ Donor updated: {donor_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Error updating donor: {e}")
            return False
    
    def delete_donor(self, donor_id: str) -> bool:
        """Delete donor profile"""
        try:
            self.db.collection(self.collection).document(donor_id).delete()
            logger.info(f"✅ Donor deleted: {donor_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Error deleting donor: {e}")
            return False
    
    def search_donors_by_blood_type(self, blood_type: str, limit: int = 10) -> List[DonorProfile]:
        """Search donors by blood type"""
        try:
            docs = self.db.collection(self.collection)\
                .where("blood_type", "==", blood_type)\
                .where("is_active", "==", True)\
                .limit(limit)\
                .stream()
            
            donors = [DonorProfile(**doc.to_dict()) for doc in docs]
            logger.info(f"✅ Found {len(donors)} donors with blood type {blood_type}")
            return donors
        except Exception as e:
            logger.error(f"❌ Error searching donors: {e}")
            return []
    
    def search_donors_by_location(self, location: str, limit: int = 10) -> List[DonorProfile]:
        """Search donors by location"""
        try:
            docs = self.db.collection(self.collection)\
                .where("location", "==", location)\
                .where("is_active", "==", True)\
                .limit(limit)\
                .stream()
            
            donors = [DonorProfile(**doc.to_dict()) for doc in docs]
            logger.info(f"✅ Found {len(donors)} donors in {location}")
            return donors
        except Exception as e:
            logger.error(f"❌ Error searching donors: {e}")
            return []

# ============================================================================
# TWILIO SMS INTEGRATION - SMS Pipeline & Alerts
# ============================================================================

class TwilioSMSPipeline:
    """SMS pipeline for alerts and notifications"""
    
    def __init__(self, account_sid: str, auth_token: str, from_number: str):
        self.client = Client(account_sid, auth_token)
        self.from_number = from_number
    
    def send_alert(self, to_number: str, message: str) -> bool:
        """Send SMS alert to blood bank on match"""
        try:
            msg = self.client.messages.create(
                body=message,
                from_=self.from_number,
                to=to_number
            )
            logger.info(f"✅ SMS sent to {to_number}: {msg.sid}")
            return True
        except Exception as e:
            logger.error(f"❌ SMS failed to {to_number}: {e}")
            return False
    
    def send_match_alert(self, blood_bank_phone: str, donor_name: str, 
                        blood_type: str, quantity: int) -> bool:
        """Send alert when blood match is found"""
        message = f"🩸 BLOOD MATCH FOUND!\n{donor_name} ({blood_type}) - {quantity} units\nRespond with CONFIRM to proceed."
        return self.send_alert(blood_bank_phone, message)
    
    def send_shortage_alert(self, blood_bank_phone: str, blood_type: str, 
                           current: int, required: int) -> bool:
        """Send alert for blood shortage prediction"""
        message = f"⚠️ SHORTAGE ALERT\n{blood_type}: {current} units (Need {required})\nDrive required in next 48hrs"
        return self.send_alert(blood_bank_phone, message)
    
    def send_offline_fallback(self, phone: str, data: str) -> str:
        """Offline SMS fallback - format data as structured text"""
        # Used when internet is down - stores message format for offline banks
        formatted = f"OFFLINE_DATA|{datetime.now().isoformat()}|{data}"
        logger.info(f"📴 Offline fallback formatted: {formatted}")
        return formatted

# ============================================================================
# FIREBASE REALTIME DB - Inventory Sync
# ============================================================================

class InventorySyncManager:
    """Manages real-time inventory sync to Firebase"""
    
    def __init__(self):
        self.db = db.reference('blood_inventory')
    
    def update_inventory(self, bank_id: str, inventory: BloodInventory) -> bool:
        """Update blood inventory in real-time database"""
        try:
            self.db.child(bank_id).child(inventory.blood_type).set(inventory.to_dict())
            logger.info(f"✅ Inventory synced: {bank_id}/{inventory.blood_type}")
            return True
        except Exception as e:
            logger.error(f"❌ Inventory sync failed: {e}")
            return False
    
    def get_inventory(self, bank_id: str, blood_type: str) -> Optional[BloodInventory]:
        """Retrieve current inventory"""
        try:
            data = self.db.child(bank_id).child(blood_type).get().val()
            if data:
                return BloodInventory(**data)
            return None
        except Exception as e:
            logger.error(f"❌ Error retrieving inventory: {e}")
            return None
    
    def get_all_inventory(self, bank_id: str) -> Dict[str, BloodInventory]:
        """Get all blood types for a bank"""
        try:
            data = self.db.child(bank_id).get().val()
            if data:
                return {k: BloodInventory(**v) for k, v in data.items()}
            return {}
        except Exception as e:
            logger.error(f"❌ Error retrieving all inventory: {e}")
            return {}

# ============================================================================
# FIREBASE CLOUD MESSAGING - Push Notifications
# ============================================================================

class PushNotificationTrigger:
    """Firebase Cloud Messaging for push notifications"""
    
    @staticmethod
    def send_notification(token: str, title: str, body: str, data: Dict = None) -> bool:
        """Send push notification via FCM"""
        try:
            message = messaging.Message(
                token=token,
                notification=messaging.Notification(
                    title=title,
                    body=body
                ),
                data=data or {}
            )
            response = messaging.send(message)
            logger.info(f"✅ Push notification sent: {response}")
            return True
        except Exception as e:
            logger.error(f"❌ Push notification failed: {e}")
            return False
    
    @staticmethod
    def send_topic_notification(topic: str, title: str, body: str, data: Dict = None) -> bool:
        """Send notification to all subscribers of a topic"""
        try:
            message = messaging.Message(
                topic=topic,
                notification=messaging.Notification(
                    title=title,
                    body=body
                ),
                data=data or {}
            )
            response = messaging.send(message)
            logger.info(f"✅ Topic notification sent to {topic}: {response}")
            return True
        except Exception as e:
            logger.error(f"❌ Topic notification failed: {e}")
            return False

# ============================================================================
# DATA PIPELINE - NBTC Historical Data & BigQuery
# ============================================================================

class NBTCDataPipeline:
    """Download, clean, and load NBTC historical data"""
    
    @staticmethod
    def download_nbtc_data(url: str = NBTC_DATA_URL) -> Optional[bytes]:
        """Download NBTC historical data"""
        try:
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                logger.info("✅ NBTC data downloaded successfully")
                return response.content
            else:
                logger.warning(f"⚠️ Failed to download NBTC data: {response.status_code}")
                return None
        except Exception as e:
            logger.error(f"❌ Error downloading NBTC data: {e}")
            return None
    
    @staticmethod
    def clean_nbtc_data(data: bytes) -> List[Dict]:
        """Clean and parse NBTC CSV data"""
        try:
            lines = data.decode('utf-8').split('\n')
            cleaned_rows = []
            
            for i, line in enumerate(lines):
                if i == 0:  # Skip header
                    continue
                if not line.strip():  # Skip empty lines
                    continue
                
                # Parse CSV (basic)
                fields = [f.strip() for f in line.split(',')]
                if len(fields) >= 3:
                    cleaned_rows.append({
                        'date': fields[0] if len(fields) > 0 else None,
                        'blood_type': fields[1] if len(fields) > 1 else None,
                        'quantity': int(fields[2]) if len(fields) > 2 and fields[2].isdigit() else 0,
                        'region': fields[3] if len(fields) > 3 else 'UNKNOWN'
                    })
            
            logger.info(f"✅ Cleaned {len(cleaned_rows)} NBTC records")
            return cleaned_rows
        except Exception as e:
            logger.error(f"❌ Error cleaning NBTC data: {e}")
            return []
    
    @staticmethod
    def load_to_bigquery(cleaned_data: List[Dict]) -> bool:
        """Load cleaned data to BigQuery (mock - requires credentials)"""
        try:
            # In production, use google.cloud.bigquery.Client()
            # For now, we log and store locally
            logger.info(f"📊 Would load {len(cleaned_data)} records to BigQuery")
            
            # Store in local JSON for reference
            with open('/tmp/nbtc_cleaned.json', 'w') as f:
                json.dump(cleaned_data, f, indent=2)
            
            logger.info("✅ NBTC data ready for BigQuery ingestion")
            return True
        except Exception as e:
            logger.error(f"❌ BigQuery load failed: {e}")
            return False

# ============================================================================
# DONATION DRIVE TRIGGER - Predictive Shortage Detection
# ============================================================================

class DonationDriveTrigger:
    """Triggers donation drive when forecast predicts shortage"""
    
    BLOOD_TYPE_THRESHOLD = {
        'O-': 50,
        'O+': 60,
        'A-': 40,
        'A+': 50,
        'B-': 35,
        'B+': 50,
        'AB-': 20,
        'AB+': 30
    }
    
    @staticmethod
    def predict_shortage(historical_data: List[Dict], current_inventory: Dict) -> List[str]:
        """Predict blood shortage in next 72 hours"""
        shortages = []
        
        for blood_type, threshold in DonationDriveTrigger.BLOOD_TYPE_THRESHOLD.items():
            current = current_inventory.get(blood_type, 0)
            
            # Simple trend: if current is below threshold, predict shortage
            if current < threshold:
                shortages.append(blood_type)
                logger.warning(f"⚠️ Shortage predicted: {blood_type} (Current: {current}, Threshold: {threshold})")
        
        return shortages
    
    @staticmethod
    def trigger_donation_drive(blood_types: List[str], location: str) -> Dict:
        """Create donation drive event when shortage predicted"""
        event = {
            'drive_id': hashlib.md5(f"{location}{datetime.now()}".encode()).hexdigest()[:8],
            'location': location,
            'blood_types_needed': blood_types,
            'created_at': datetime.now().isoformat(),
            'urgency': 'HIGH' if len(blood_types) > 3 else 'MEDIUM',
            'target_donations': sum(DonationDriveTrigger.BLOOD_TYPE_THRESHOLD.get(bt, 50) for bt in blood_types),
            'status': 'ACTIVE'
        }
        
        logger.info(f"🚨 Donation drive triggered: {event['drive_id']}")
        return event

# ============================================================================
# OFFLINE SMS FALLBACK - No Internet Support
# ============================================================================

class OfflineSMSFallback:
    """Offline SMS fallback for no-internet blood banks"""
    
    @staticmethod
    def initialize_offline_db():
        """Initialize SQLite database for offline mode"""
        try:
            conn = sqlite3.connect(OFFLINE_DB)
            cursor = conn.cursor()
            
            # Create tables for offline storage
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS offline_messages (
                    id INTEGER PRIMARY KEY,
                    phone TEXT,
                    message TEXT,
                    timestamp TEXT,
                    status TEXT DEFAULT 'PENDING'
                )
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS offline_inventory (
                    bank_id TEXT PRIMARY KEY,
                    blood_data TEXT,
                    last_synced TEXT
                )
            ''')
            
            conn.commit()
            conn.close()
            logger.info("✅ Offline database initialized")
            return True
        except Exception as e:
            logger.error(f"❌ Offline DB init failed: {e}")
            return False
    
    @staticmethod
    def queue_offline_message(phone: str, message: str) -> bool:
        """Queue message for offline transmission"""
        try:
            conn = sqlite3.connect(OFFLINE_DB)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO offline_messages (phone, message, timestamp, status)
                VALUES (?, ?, ?, ?)
            ''', (phone, message, datetime.now().isoformat(), 'PENDING'))
            
            conn.commit()
            conn.close()
            logger.info(f"📴 Message queued for offline: {phone}")
            return True
        except Exception as e:
            logger.error(f"❌ Error queueing offline message: {e}")
            return False
    
    @staticmethod
    def sync_offline_queue(sms_pipeline: TwilioSMSPipeline) -> int:
        """Sync queued offline messages when internet returns"""
        try:
            conn = sqlite3.connect(OFFLINE_DB)
            cursor = conn.cursor()
            
            cursor.execute('SELECT id, phone, message FROM offline_messages WHERE status = "PENDING"')
            pending = cursor.fetchall()
            
            sent_count = 0
            for msg_id, phone, message in pending:
                if sms_pipeline.send_alert(phone, message):
                    cursor.execute('UPDATE offline_messages SET status = "SENT" WHERE id = ?', (msg_id,))
                    sent_count += 1
            
            conn.commit()
            conn.close()
            
            logger.info(f"✅ Synced {sent_count} offline messages")
            return sent_count
        except Exception as e:
            logger.error(f"❌ Offline sync failed: {e}")
            return 0

# ============================================================================
# SCHEDULED TASKS - e-RaktKosh Scraper & Sync
# ============================================================================

class ScheduledTasks:
    """Scheduled tasks for automated data sync and processing"""
    
    def __init__(self):
        self.inventory_manager = InventorySyncManager()
        self.firestore = FirestoreBackend()
        self.sms = TwilioSMSPipeline(
            TWILIO_CONFIG['account_sid'],
            TWILIO_CONFIG['auth_token'],
            TWILIO_CONFIG['from_number']
        )
        self.offline = OfflineSMSFallback()
    
    def sync_e_raktkosh_to_firebase(self):
        """Sync e-RaktKosh inventory every 6 hours"""
        logger.info("🔄 Starting e-RaktKosh sync to Firebase...")
        
        # Mock e-RaktKosh data (in production, scrape from actual source)
        mock_banks = {
            'BANK_PUNE_001': {
                'O-': BloodInventory('O-', 45, datetime.now().isoformat(), 'BANK_PUNE_001', 
                                    (datetime.now() + timedelta(days=35)).isoformat()),
                'O+': BloodInventory('O+', 60, datetime.now().isoformat(), 'BANK_PUNE_001',
                                    (datetime.now() + timedelta(days=35)).isoformat()),
                'A+': BloodInventory('A+', 35, datetime.now().isoformat(), 'BANK_PUNE_001',
                                    (datetime.now() + timedelta(days=35)).isoformat()),
            },
            'BANK_MUMBAI_001': {
                'B+': BloodInventory('B+', 50, datetime.now().isoformat(), 'BANK_MUMBAI_001',
                                    (datetime.now() + timedelta(days=35)).isoformat()),
                'AB-': BloodInventory('AB-', 15, datetime.now().isoformat(), 'BANK_MUMBAI_001',
                                     (datetime.now() + timedelta(days=35)).isoformat()),
            }
        }
        
        synced = 0
        for bank_id, inventory in mock_banks.items():
            for blood_type, inv_obj in inventory.items():
                if self.inventory_manager.update_inventory(bank_id, inv_obj):
                    synced += 1
        
        logger.info(f"✅ Synced {synced} inventory records to Firebase")
    
    def process_nbtc_data(self):
        """Download and process NBTC data daily"""
        logger.info("📊 Starting NBTC data processing...")
        
        raw_data = NBTCDataPipeline.download_nbtc_data()
        if raw_data:
            cleaned_data = NBTCDataPipeline.clean_nbtc_data(raw_data)
            NBTCDataPipeline.load_to_bigquery(cleaned_data)
        else:
            logger.warning("⚠️ NBTC data download failed, using cached data")
    
    def check_shortage_predictions(self):
        """Check for predicted shortages and trigger drives"""
        logger.info("🚨 Checking for blood shortages...")
        
        # Mock current inventory for testing
        current_inventory = {'O-': 40, 'O+': 55, 'A-': 35, 'A+': 45, 'B-': 30, 'B+': 48}
        
        shortages = DonationDriveTrigger.predict_shortage([], current_inventory)
        if shortages:
            drive = DonationDriveTrigger.trigger_donation_drive(shortages, 'PUNE')
            logger.info(f"🎯 Donation drive created: {drive}")
            
            # Send SMS alert
            self.sms.send_shortage_alert(
                '+919876543210',  # Blood bank contact
                shortages[0],
                current_inventory.get(shortages[0], 0),
                ScheduledTasks._get_threshold(shortages[0])
            )
    
    @staticmethod
    def _get_threshold(blood_type: str) -> int:
        return DonationDriveTrigger.BLOOD_TYPE_THRESHOLD.get(blood_type, 50)
    
    def sync_offline_messages(self):
        """Sync offline queued messages when connectivity returns"""
        logger.info("📤 Syncing offline messages...")
        self.offline.sync_offline_queue(self.sms)

# ============================================================================
# MAIN ORCHESTRATOR
# ============================================================================

class RaktSetuIntegration:
    """Main P3 Integration Engineer Orchestrator"""
    
    def __init__(self):
        self.scheduled_tasks = None
        self.sms_pipeline = None
        self.firestore = None
        self.offline = None
    
    def initialize(self) -> bool:
        """Initialize all systems"""
        logger.info("🚀 Initializing RAKT-SETU P3 Integration...")
        
        # 1. Initialize Firebase
        if not initialize_firebase():
            logger.error("❌ Firebase initialization failed")
            return False
        
        # 2. Initialize offline database
        if not OfflineSMSFallback.initialize_offline_db():
            logger.error("❌ Offline DB initialization failed")
            return False
        
        # 3. Initialize components
        self.scheduled_tasks = ScheduledTasks()
        self.sms_pipeline = self.scheduled_tasks.sms
        self.firestore = self.scheduled_tasks.firestore
        self.offline = self.scheduled_tasks.offline
        
        logger.info("✅ All systems initialized successfully")
        return True
    
    def schedule_tasks(self):
        """Schedule all recurring tasks"""
        logger.info("📅 Scheduling recurring tasks...")
        
        # Every 6 hours: e-RaktKosh sync
        schedule.every(6).hours.do(self.scheduled_tasks.sync_e_raktkosh_to_firebase)
        
        # Every 24 hours: NBTC data processing
        schedule.every(1).day.do(self.scheduled_tasks.process_nbtc_data)
        
        # Every 3 hours: Check for shortages
        schedule.every(3).hours.do(self.scheduled_tasks.check_shortage_predictions)
        
        # Every 30 minutes: Sync offline messages
        schedule.every(30).minutes.do(self.scheduled_tasks.sync_offline_messages)
        
        logger.info("✅ Tasks scheduled successfully")
    
    def run_scheduler(self, duration_seconds: int = 60):
        """Run scheduler for specified duration (for testing)"""
        logger.info(f"⏱️ Running scheduler for {duration_seconds} seconds...")
        
        end_time = time.time() + duration_seconds
        while time.time() < end_time:
            schedule.run_pending()
            time.sleep(1)
        
        logger.info("✅ Scheduler test completed")
    
    def demo_workflows(self):
        """Demonstrate all P3 workflows"""
        logger.info("\n" + "="*70)
        logger.info("🎯 DEMONSTRATING P3 WORKFLOWS")
        logger.info("="*70 + "\n")
        
        # 1. Demonstrate Firestore CRUD
        logger.info("1️⃣ FIRESTORE DONOR REGISTRY (CRUD + Search)")
        logger.info("-" * 70)
        
        donor1 = DonorProfile(
            donor_id='DONOR_001',
            name='Rajesh Kumar',
            blood_type='O+',
            phone='+919876543210',
            last_donation='2024-04-20',
            donation_count=5,
            location='PUNE',
            is_active=True
        )
        
        self.firestore.create_donor(donor1)
        retrieved = self.firestore.read_donor('DONOR_001')
        if retrieved:
            logger.info(f"✅ Retrieved donor: {retrieved.name} ({retrieved.blood_type})")
        
        self.firestore.update_donor('DONOR_001', {'donation_count': 6})
        donors = self.firestore.search_donors_by_blood_type('O+', limit=5)
        logger.info(f"✅ Search by blood type O+: Found {len(donors)} donors")
        
        # 2. Demonstrate SMS Pipeline
        logger.info("\n2️⃣ TWILIO SMS PIPELINE (Match Alerts)")
        logger.info("-" * 70)
        
        self.sms_pipeline.send_match_alert(
            '+919876543210',
            'Rajesh Kumar',
            'O+',
            3
        )
        
        # 3. Demonstrate Firebase Inventory Sync
        logger.info("\n3️⃣ FIREBASE INVENTORY SYNC (Real-time)")
        logger.info("-" * 70)
        
        inv = BloodInventory(
            blood_type='O+',
            quantity=65,
            last_updated=datetime.now().isoformat(),
            bank_id='SASSOON_HOSPITAL',
            expiry_date=(datetime.now() + timedelta(days=35)).isoformat()
        )
        
        inventory_manager = InventorySyncManager()
        inventory_manager.update_inventory('SASSOON_HOSPITAL', inv)
        
        # 4. Demonstrate Push Notifications
        logger.info("\n4️⃣ FIREBASE CLOUD MESSAGING (Push Notifications)")
        logger.info("-" * 70)
        
        logger.info("✅ Push notification (requires valid FCM token):")
        logger.info("   Title: Blood Match Found")
        logger.info("   Body: O+ match available at Sassoon Hospital")
        
        # 5. Demonstrate NBTC Data Pipeline
        logger.info("\n5️⃣ NBTC DATA PIPELINE (BigQuery)")
        logger.info("-" * 70)
        
        self.scheduled_tasks.process_nbtc_data()
        
        # 6. Demonstrate Shortage Prediction
        logger.info("\n6️⃣ DONATION DRIVE TRIGGER (Predictive)")
        logger.info("-" * 70)
        
        self.scheduled_tasks.check_shortage_predictions()
        
        # 7. Demonstrate Offline Fallback
        logger.info("\n7️⃣ OFFLINE SMS FALLBACK (No Internet)")
        logger.info("-" * 70)
        
        self.offline.queue_offline_message(
            '+919876543210',
            'OFFLINE: B+ shortage - 3 units needed'
        )
        logger.info("✅ Offline message queued (will sync when online)")
        
        logger.info("\n" + "="*70)
        logger.info("✅ ALL P3 WORKFLOWS DEMONSTRATED SUCCESSFULLY")
        logger.info("="*70 + "\n")
    
    def run(self, test_mode: bool = True, duration: int = 60):
        """Run the complete P3 integration"""
        if not self.initialize():
            return False
        
        if test_mode:
            logger.info("\n🧪 RUNNING IN TEST MODE\n")
            self.demo_workflows()
            self.schedule_tasks()
            self.run_scheduler(duration)
        else:
            logger.info("\n⚙️ RUNNING IN PRODUCTION MODE\n")
            self.schedule_tasks()
            
            try:
                while True:
                    schedule.run_pending()
                    time.sleep(1)
            except KeyboardInterrupt:
                logger.info("👋 Scheduler stopped by user")
        
        return True

# ============================================================================
# ENTRY POINT
# ============================================================================

def main():
    """Entry point"""
    integration = RaktSetuIntegration()
    
    # Run in test mode for 60 seconds, demonstrating all workflows
    success = integration.run(test_mode=True, duration=60)
    
    if success:
        logger.info("\n✅ P3 Integration completed successfully!")
        print("\n" + "="*70)
        print("📋 SUMMARY")
        print("="*70)
        print("✅ Firestore Donor Registry (CRUD + Search API)")
        print("✅ Twilio SMS Pipeline (Match alerts)")
        print("✅ Firebase Real-time Inventory Sync (every 6 hrs)")
        print("✅ Push Notifications (Firebase Cloud Messaging)")
        print("✅ NBTC Data Pipeline (Download → Clean → BigQuery)")
        print("✅ Donation Drive Triggers (Predictive shortage)")
        print("✅ Offline SMS Fallback (SQLite queue)")
        print("="*70)
    else:
        logger.error("\n❌ P3 Integration failed!")

if __name__ == "__main__":
    main()
