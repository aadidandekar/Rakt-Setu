# RAKT-SETU P3 - Quick Reference Card

## 🚀 30-Second Start

```bash
# 1. Install dependencies
pip install --break-system-packages firebase-admin twilio schedule requests

# 2. Get your Twilio number from https://www.twilio.com/console/phone-numbers/incoming

# 3. Edit main.py - line 75 - replace "+1234567890" with your Twilio number

# 4. Run it!
python3 main.py
```

**Expected in 60 seconds:**
```
✅ Firebase initialized
✅ Firestore CRUD demo
✅ SMS alerts logged
✅ Inventory synced
✅ Donation drives triggered
✅ Offline queue created
```

---

## 📊 What Each Class Does

| Class | Purpose | Key Methods |
|-------|---------|------------|
| `FirestoreBackend` | Donor registry CRUD + search | `create_donor()`, `search_donors_by_blood_type()` |
| `TwilioSMSPipeline` | SMS alerts to blood banks | `send_alert()`, `send_match_alert()` |
| `InventorySyncManager` | Real-time blood inventory | `update_inventory()`, `get_inventory()` |
| `PushNotificationTrigger` | Firebase push notifications | `send_notification()`, `send_topic_notification()` |
| `NBTCDataPipeline` | Download & process NBTC data | `download_nbtc_data()`, `clean_nbtc_data()` |
| `DonationDriveTrigger` | Predict & trigger donation drives | `predict_shortage()`, `trigger_donation_drive()` |
| `OfflineSMSFallback` | Queue msgs when offline | `queue_offline_message()`, `sync_offline_queue()` |
| `ScheduledTasks` | Automated recurring tasks | All tasks run on schedule |

---

## 🔑 Key Functions - Copy & Paste Examples

### Create Donor
```python
from main import FirestoreBackend, DonorProfile

db = FirestoreBackend()
donor = DonorProfile(
    donor_id='DONOR_123',
    name='Rajesh Kumar',
    blood_type='O+',
    phone='+919876543210',
    last_donation='2024-04-20',
    donation_count=5,
    location='PUNE',
    is_active=True
)
db.create_donor(donor)
```

### Search Donors
```python
# By blood type
donors = db.search_donors_by_blood_type('O+', limit=10)

# By location
donors = db.search_donors_by_location('PUNE', limit=10)

for donor in donors:
    print(f"{donor.name} - {donor.blood_type}")
```

### Send SMS Alert
```python
from main import TwilioSMSPipeline

sms = TwilioSMSPipeline(
    "AC9115df704d3ee832fe76947677d7d1a5",
    "efe4fd9b953b85e7cdac3a90d7f4500f",
    "+919876543210"  # YOUR TWILIO NUMBER
)

sms.send_match_alert(
    to_number='+919876543210',
    donor_name='Rajesh Kumar',
    blood_type='O+',
    quantity=3
)
```

### Update Blood Inventory
```python
from main import InventorySyncManager, BloodInventory
from datetime import datetime, timedelta

manager = InventorySyncManager()
inv = BloodInventory(
    blood_type='O+',
    quantity=65,
    last_updated=datetime.now().isoformat(),
    bank_id='SASSOON_HOSPITAL',
    expiry_date=(datetime.now() + timedelta(days=35)).isoformat()
)
manager.update_inventory('SASSOON_HOSPITAL', inv)
```

### Predict Shortages
```python
from main import DonationDriveTrigger

current_inventory = {
    'O-': 40,   # Below 50 threshold
    'O+': 55,   # Below 60 threshold
    'A+': 45,   # Below 50 threshold
}

shortages = DonationDriveTrigger.predict_shortage([], current_inventory)
print(f"Predicted shortages: {shortages}")
# Output: ['O-', 'O+', 'A+']

if shortages:
    drive = DonationDriveTrigger.trigger_donation_drive(shortages, 'PUNE')
    print(f"Drive ID: {drive['drive_id']}")
```

### Queue Offline Message
```python
from main import OfflineSMSFallback

OfflineSMSFallback.queue_offline_message(
    phone='+919876543210',
    message='B+ shortage alert'
)
# Message queued in SQLite, synced when online
```

---

## ⏰ Automatic Scheduled Tasks

These run automatically - no code needed:

```python
# Every 6 hours
sync_e_raktkosh_to_firebase()

# Every 24 hours  
process_nbtc_data()

# Every 3 hours
check_shortage_predictions()

# Every 30 minutes
sync_offline_messages()
```

To change timing, edit in `ScheduledTasks` class:
```python
schedule.every(3).hours.do(...)  # Change 3 to desired hours
```

---

## 🔐 Credentials Status

| Service | Status | What You Need |
|---------|--------|--------------|
| Firebase | ✅ Ready | Nothing (embedded) |
| Twilio Account SID | ✅ Ready | `AC9115df704d3ee832fe76947677d7d1a5` |
| Twilio Auth Token | ✅ Ready | `efe4fd9b953b85e7cdac3a90d7f4500f` |
| **Twilio Phone Number** | ❌ **REQUIRED** | Get from [console.twilio.com](https://www.twilio.com/console/phone-numbers/incoming) |

**How to get Twilio Phone Number:**
1. Go to https://www.twilio.com/console/phone-numbers/incoming
2. Click "Buy a Number"
3. Select country (India = +91, US = +1)
4. Click "Buy"
5. Copy the number
6. Edit line 75 in main.py:
```python
"from_number": "+919876543210",  # Paste your number here
```

---

## 🧪 Quick Tests

### Test 1: Run Full Demo (60 seconds)
```bash
python3 main.py
```

### Test 2: Test SMS (requires Twilio number)
```python
from main import TwilioSMSPipeline

sms = TwilioSMSPipeline(
    "AC9115df704d3ee832fe76947677d7d1a5",
    "efe4fd9b953b85e7cdac3a90d7f4500f",
    "+919876543210"  # YOUR TWILIO NUMBER
)

sms.send_alert("+919876543210", "Test message")
# Check your phone for SMS
```

### Test 3: Check Offline DB
```bash
sqlite3 blood_bank_offline.db
sqlite> .tables
offline_messages  offline_inventory

sqlite> SELECT * FROM offline_messages;
```

### Test 4: Check NBTC Data Download
```bash
ls -la /tmp/nbtc_cleaned.json
cat /tmp/nbtc_cleaned.json | head -20
```

### Test 5: Firebase Inventory Check
```python
from main import InventorySyncManager

manager = InventorySyncManager()
inv = manager.get_inventory('SASSOON_HOSPITAL', 'O+')
print(f"O+ available: {inv.quantity} units")
```

---

## 📱 HTTP API Endpoints (To Implement)

If deploying as REST API:

```bash
# Donor Management
POST   /api/donors                 # Create
GET    /api/donors/{id}            # Read
PUT    /api/donors/{id}            # Update
DELETE /api/donors/{id}            # Delete
GET    /api/donors?blood_type=O+   # Search by type
GET    /api/donors?location=PUNE   # Search by location

# Inventory
GET    /api/inventory/{bank_id}/{blood_type}
PUT    /api/inventory/{bank_id}/{blood_type}
GET    /api/inventory/{bank_id}

# SMS
POST   /api/sms/alert
POST   /api/sms/match-alert
POST   /api/sms/shortage-alert

# Drives
GET    /api/drives
GET    /api/drives/{drive_id}

# Offline
GET    /api/offline/queue
POST   /api/offline/sync
```

---

## 🐛 Troubleshooting 5-Minute Fix

| Error | Fix |
|-------|-----|
| `ModuleNotFoundError: firebase_admin` | `pip install --break-system-packages firebase-admin` |
| `ModuleNotFoundError: twilio` | `pip install --break-system-packages twilio` |
| `Firebase initialization failed` | Check internet, verify credentials |
| `SMS failed` | Update `from_number` to real Twilio number |
| `Permission denied Firestore` | Update Firebase rules (see SETUP_GUIDE.md) |
| `ModuleNotFoundError: schedule` | `pip install --break-system-packages schedule` |

---

## 📈 Production Checklist

- [ ] Replace `from_number` with real Twilio number
- [ ] Set `test_mode=False` for infinite running
- [ ] Use environment variables for credentials
- [ ] Deploy to Docker/Railway/Cloud Run
- [ ] Monitor logs regularly
- [ ] Set up error notifications
- [ ] Backup offline database weekly
- [ ] Test offline fallback monthly

---

## 📚 File Structure

```
rakt-setu/
├── main.py                    # 🔧 All code here (500+ lines)
├── SETUP_GUIDE.md             # 📖 Detailed setup guide
├── QUICK_REFERENCE.md         # 📋 This file
├── API_CONTRACTS.md           # 📡 REST API specs
├── blood_bank_offline.db      # 💾 SQLite offline queue
└── rakt-setu.log              # 📝 Log file (created on run)
```

---

## 🎯 What Gets Logged

```
[10:30:45] ✅ Firebase initialized
[10:30:46] ✅ Offline database initialized
[10:30:47] ✅ All systems initialized

[10:31:00] ✅ Donor created: DONOR_001
[10:31:01] ✅ Retrieved donor: Rajesh Kumar (O+)
[10:31:02] ✅ SMS sent to +919876543210
[10:31:03] ✅ Inventory synced: SASSOON_HOSPITAL/O+

[10:31:10] ⚠️ Shortage predicted: O- (Current: 40, Threshold: 50)
[10:31:11] 🚨 Donation drive triggered: abc12345

[10:31:20] 📴 Message queued for offline: +919876543210
[10:31:21] 📤 Synced 0 offline messages
```

---

## 🤔 FAQ

**Q: Do I need to deploy this to a server?**
A: No, run it locally first. For production, use Docker + Railway/Render.

**Q: Will SMS actually be sent?**
A: Yes! But only to your Twilio number (and you need to set it up).

**Q: Can I run this on my Raspberry Pi?**
A: Yes, just install Python 3.8+

**Q: How much does Twilio cost?**
A: SMS is cheap ($0.0075/msg in US, ~₹0.50 in India)

**Q: Will it work without internet?**
A: Yes! Offline mode queues everything, syncs when online.

**Q: Can I use this for my own blood bank?**
A: Absolutely! Just change bank IDs and numbers.

---

## 💬 Need Help?

1. Check **SETUP_GUIDE.md** for detailed setup
2. Check **API_CONTRACTS.md** for API specs
3. Run in test mode: `python3 main.py`
4. Check logs for errors
5. Review `main.py` - it's fully commented
