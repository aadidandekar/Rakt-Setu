# RAKT-SETU P3 - API Contracts & Integration Specs

**Status:** Production Ready  
**Version:** 1.0.0  
**Last Updated:** 2024-04-26

---

## Table of Contents

1. [Overview](#overview)
2. [Base Configuration](#base-configuration)
3. [Donor Registry API](#donor-registry-api-firestore)
4. [SMS Pipeline API](#sms-pipeline-api-twilio)
5. [Inventory Sync API](#inventory-sync-api-firebase)
6. [Push Notifications API](#push-notifications-api-fcm)
7. [Data Pipeline API](#data-pipeline-api-nbtc--bigquery)
8. [Donation Drive API](#donation-drive-api)
9. [Offline Queue API](#offline-queue-api)
10. [Error Codes](#error-codes)
11. [Example Workflows](#example-workflows)

---

## Overview

RAKT-SETU uses multiple services:
- **Firestore** - Donor registry (CRUD + search)
- **Firebase Realtime DB** - Blood inventory (real-time sync)
- **Twilio** - SMS alerts and notifications
- **Firebase Cloud Messaging** - Push notifications
- **BigQuery** - Historical data analytics
- **SQLite** - Offline mode queue

---

## Base Configuration

### Authentication
All Firebase APIs use the following config:

```json
{
  "apiKey": "AIzaSyClqb7F7u0_eIBTKZ--zSm0qZCjAStBWPI",
  "authDomain": "blood-bank-401718.firebaseapp.com",
  "databaseURL": "https://blood-bank-401718-default-rtdb.firebaseio.com",
  "projectId": "blood-bank-401718",
  "storageBucket": "blood-bank-401718.firebasestorage.app",
  "messagingSenderId": "517187399539",
  "appId": "1:517187399539:web:c5855d0d79fc6363fe1f06"
}
```

### Twilio Configuration
```json
{
  "account_sid": "AC9115df704d3ee832fe76947677d7d1a5",
  "auth_token": "efe4fd9b953b85e7cdac3a90d7f4500f",
  "from_number": "+919876543210"
}
```

---

## Donor Registry API (Firestore)

### Collection: `/donors`

**Document Structure:**
```json
{
  "donor_id": "DONOR_001",
  "name": "Rajesh Kumar",
  "blood_type": "O+",
  "phone": "+919876543210",
  "last_donation": "2024-04-20",
  "donation_count": 5,
  "location": "PUNE",
  "is_active": true,
  "email": "rajesh@example.com",
  "age": 28,
  "gender": "M",
  "medical_conditions": [],
  "created_at": "2024-04-20T10:30:00Z",
  "updated_at": "2024-04-26T10:30:00Z"
}
```

### Endpoints (Python)

#### CREATE Donor
```python
POST /donors

donor = DonorProfile(
    donor_id='DONOR_001',
    name='Rajesh Kumar',
    blood_type='O+',
    phone='+919876543210',
    last_donation='2024-04-20',
    donation_count=5,
    location='PUNE',
    is_active=True
)
db.create_donor(donor)

# Response (200 OK)
{
  "success": true,
  "donor_id": "DONOR_001",
  "message": "Donor created successfully"
}

# Response (400 Bad Request)
{
  "success": false,
  "error": "donor_id already exists"
}
```

#### READ Donor
```python
GET /donors/{donor_id}

donor = db.read_donor('DONOR_001')

# Response (200 OK)
{
  "success": true,
  "donor": {
    "donor_id": "DONOR_001",
    "name": "Rajesh Kumar",
    "blood_type": "O+",
    ...
  }
}

# Response (404 Not Found)
{
  "success": false,
  "error": "Donor not found"
}
```

#### UPDATE Donor
```python
PUT /donors/{donor_id}

db.update_donor('DONOR_001', {
    'donation_count': 6,
    'last_donation': '2024-04-26'
})

# Response (200 OK)
{
  "success": true,
  "donor_id": "DONOR_001",
  "message": "Donor updated successfully"
}
```

#### DELETE Donor
```python
DELETE /donors/{donor_id}

db.delete_donor('DONOR_001')

# Response (200 OK)
{
  "success": true,
  "message": "Donor deleted successfully"
}
```

#### SEARCH by Blood Type
```python
GET /donors?blood_type=O+&limit=10

donors = db.search_donors_by_blood_type('O+', limit=10)

# Response (200 OK)
{
  "success": true,
  "count": 5,
  "donors": [
    {
      "donor_id": "DONOR_001",
      "name": "Rajesh Kumar",
      "blood_type": "O+",
      "location": "PUNE",
      "phone": "+919876543210",
      "last_donation": "2024-04-20"
    },
    ...
  ]
}
```

#### SEARCH by Location
```python
GET /donors?location=PUNE&limit=10

donors = db.search_donors_by_location('PUNE', limit=10)

# Response (200 OK)
{
  "success": true,
  "count": 3,
  "location": "PUNE",
  "donors": [...]
}
```

---

## SMS Pipeline API (Twilio)

### Endpoints

#### Send Simple Alert
```python
POST /sms/alert

sms.send_alert(
    to_number='+919876543210',
    message='Blood match found at Sassoon Hospital'
)

# Response (200 OK)
{
  "success": true,
  "sid": "SM1234567890abcdef",
  "to": "+919876543210",
  "status": "queued"
}

# Response (400 Bad Request)
{
  "success": false,
  "error": "Invalid phone number format"
}
```

#### Send Match Alert
```python
POST /sms/match-alert

sms.send_match_alert(
    blood_bank_phone='+919876543210',
    donor_name='Rajesh Kumar',
    blood_type='O+',
    quantity=3
)

# Message Format:
# "🩸 BLOOD MATCH FOUND!
#  Rajesh Kumar (O+) - 3 units
#  Respond with CONFIRM to proceed."

# Response (200 OK)
{
  "success": true,
  "sid": "SM1234567890abcdef",
  "status": "queued",
  "message": "Alert sent to blood bank"
}
```

#### Send Shortage Alert
```python
POST /sms/shortage-alert

sms.send_shortage_alert(
    blood_bank_phone='+919876543210',
    blood_type='O-',
    current=40,
    required=50
)

# Message Format:
# "⚠️ SHORTAGE ALERT
#  O-: 40 units (Need 50)
#  Drive required in next 48hrs"

# Response (200 OK)
{
  "success": true,
  "sid": "SM1234567890abcdef"
}
```

#### Offline SMS Fallback
```python
POST /sms/offline-fallback

formatted = sms.send_offline_fallback(
    phone='+919876543210',
    data='B+ shortage alert'
)

# Response (200 OK)
{
  "success": true,
  "status": "queued_offline",
  "formatted": "OFFLINE_DATA|2024-04-26T10:30:00|B+ shortage alert"
}
```

---

## Inventory Sync API (Firebase Realtime DB)

### Structure: `/blood_inventory/{bank_id}/{blood_type}`

**Document:**
```json
{
  "blood_type": "O+",
  "quantity": 65,
  "last_updated": "2024-04-26T10:30:00Z",
  "bank_id": "SASSOON_HOSPITAL",
  "expiry_date": "2024-05-31",
  "shelf_life_hours": 504,
  "temperature": 2,
  "location": "Fridge A1"
}
```

### Endpoints

#### UPDATE Inventory
```python
PUT /inventory/{bank_id}/{blood_type}

inv = BloodInventory(
    blood_type='O+',
    quantity=65,
    last_updated='2024-04-26T10:30:00Z',
    bank_id='SASSOON_HOSPITAL',
    expiry_date='2024-05-31'
)
manager.update_inventory('SASSOON_HOSPITAL', inv)

# Response (200 OK)
{
  "success": true,
  "bank_id": "SASSOON_HOSPITAL",
  "blood_type": "O+",
  "quantity": 65,
  "last_updated": "2024-04-26T10:30:00Z"
}
```

#### GET Single Inventory
```python
GET /inventory/{bank_id}/{blood_type}

inv = manager.get_inventory('SASSOON_HOSPITAL', 'O+')

# Response (200 OK)
{
  "success": true,
  "blood_type": "O+",
  "quantity": 65,
  "last_updated": "2024-04-26T10:30:00Z",
  "bank_id": "SASSOON_HOSPITAL",
  "expiry_date": "2024-05-31"
}
```

#### GET All Inventory for Bank
```python
GET /inventory/{bank_id}

all_inv = manager.get_all_inventory('SASSOON_HOSPITAL')

# Response (200 OK)
{
  "success": true,
  "bank_id": "SASSOON_HOSPITAL",
  "inventory": {
    "O+": {
      "quantity": 65,
      "expiry_date": "2024-05-31"
    },
    "O-": {
      "quantity": 45,
      "expiry_date": "2024-05-28"
    },
    "A+": {
      "quantity": 35,
      "expiry_date": "2024-05-25"
    }
  }
}
```

---

## Push Notifications API (Firebase Cloud Messaging)

### Endpoints

#### Send to Device
```python
POST /notifications/device

PushNotificationTrigger.send_notification(
    token='device_fcm_token_here',
    title='Blood Match Found',
    body='O+ available at Sassoon Hospital',
    data={
        'hospital': 'SASSOON',
        'blood_type': 'O+',
        'quantity': 3
    }
)

# Response (200 OK)
{
  "success": true,
  "message_id": "projects/blood-bank-401718/messages/..."
}
```

#### Send to Topic
```python
POST /notifications/topic

PushNotificationTrigger.send_topic_notification(
    topic='blood_alerts',
    title='Urgent Blood Needed',
    body='A- shortage in Pune',
    data={
        'blood_type': 'A-',
        'location': 'PUNE',
        'urgency': 'HIGH'
    }
)

# Response (200 OK)
{
  "success": true,
  "message_id": "..."
}
```

### Required FCM Token

To get FCM token in your client app:

**JavaScript/Web:**
```javascript
import { getMessaging, getToken } from "firebase/messaging";

const messaging = getMessaging();
const token = await getToken(messaging, {
  vapidKey: 'YOUR_VAPID_KEY'
});
console.log(token);
```

**Android:**
```kotlin
val token = FirebaseMessaging.getInstance().token
```

**iOS:**
```swift
let token = try await Messaging.messaging().token()
```

---

## Data Pipeline API (NBTC + BigQuery)

### Endpoints

#### Download NBTC Data
```python
GET /data/nbtc/download

raw_data = NBTCDataPipeline.download_nbtc_data()

# Response (200 OK)
{
  "success": true,
  "size_bytes": 245632,
  "format": "csv",
  "source": "https://nbtc.gov.in/..."
}
```

#### Clean NBTC Data
```python
POST /data/nbtc/clean

cleaned_data = NBTCDataPipeline.clean_nbtc_data(raw_data)

# Response (200 OK)
{
  "success": true,
  "records_processed": 1250,
  "records_cleaned": 1248,
  "error_rows": 2,
  "sample": [
    {
      "date": "2024-04-20",
      "blood_type": "O+",
      "quantity": 250,
      "region": "MAHARASHTRA"
    }
  ]
}
```

#### Load to BigQuery
```python
POST /data/nbtc/load-bigquery

NBTCDataPipeline.load_to_bigquery(cleaned_data)

# Response (200 OK)
{
  "success": true,
  "records_loaded": 1248,
  "table": "blood-bank-401718.public.nbtc_data",
  "load_time_seconds": 15
}
```

### BigQuery Schema

```sql
CREATE TABLE nbtc_data (
  date STRING,
  blood_type STRING,
  quantity INT64,
  region STRING,
  loaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);
```

---

## Donation Drive API

### Collection: `/donation_drives`

**Document:**
```json
{
  "drive_id": "abc12345",
  "location": "PUNE",
  "blood_types_needed": ["O-", "A-", "B+"],
  "created_at": "2024-04-26T10:30:00Z",
  "urgency": "HIGH",
  "target_donations": 200,
  "status": "ACTIVE",
  "predicted_shortage_date": "2024-04-28",
  "responsible_hospital": "SASSOON_HOSPITAL"
}
```

### Endpoints

#### Predict Shortage
```python
GET /drives/predict-shortage

shortages = DonationDriveTrigger.predict_shortage(
    historical_data=[],
    current_inventory={
        'O-': 40,
        'O+': 55,
        'A-': 35
    }
)

# Response (200 OK)
{
  "success": true,
  "predicted_shortages": ["O-", "A-"],
  "predictions": [
    {
      "blood_type": "O-",
      "current": 40,
      "threshold": 50,
      "days_until_shortage": 2
    }
  ]
}
```

#### Trigger Donation Drive
```python
POST /drives

drive = DonationDriveTrigger.trigger_donation_drive(
    blood_types=['O-', 'A-'],
    location='PUNE'
)

# Response (201 Created)
{
  "success": true,
  "drive_id": "abc12345",
  "location": "PUNE",
  "blood_types_needed": ["O-", "A-"],
  "target_donations": 150,
  "status": "ACTIVE"
}
```

#### GET Drive Status
```python
GET /drives/{drive_id}

# Response (200 OK)
{
  "success": true,
  "drive_id": "abc12345",
  "location": "PUNE",
  "blood_types_needed": ["O-", "A-"],
  "status": "ACTIVE",
  "target_donations": 150,
  "donations_received": 45,
  "completion_percentage": 30
}
```

---

## Offline Queue API

### Structure: SQLite Tables

#### offline_messages
```sql
CREATE TABLE offline_messages (
  id INTEGER PRIMARY KEY,
  phone TEXT NOT NULL,
  message TEXT NOT NULL,
  timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
  status TEXT DEFAULT 'PENDING'  -- PENDING, SENT, FAILED
);
```

#### offline_inventory
```sql
CREATE TABLE offline_inventory (
  bank_id TEXT PRIMARY KEY,
  blood_data TEXT NOT NULL,  -- JSON
  last_synced TEXT
);
```

### Endpoints

#### Queue Offline Message
```python
POST /offline/queue

OfflineSMSFallback.queue_offline_message(
    phone='+919876543210',
    message='B+ shortage alert'
)

# Response (200 OK)
{
  "success": true,
  "message_id": 1,
  "status": "queued_offline"
}
```

#### GET Pending Messages
```python
GET /offline/pending

# Response (200 OK)
{
  "success": true,
  "pending_count": 3,
  "messages": [
    {
      "id": 1,
      "phone": "+919876543210",
      "message": "B+ shortage alert",
      "timestamp": "2024-04-26T10:30:00Z",
      "status": "PENDING"
    }
  ]
}
```

#### Sync Offline Queue
```python
POST /offline/sync

sent_count = OfflineSMSFallback.sync_offline_queue(sms_pipeline)

# Response (200 OK)
{
  "success": true,
  "synced": 3,
  "failed": 0,
  "results": [
    {
      "id": 1,
      "phone": "+919876543210",
      "status": "SENT"
    }
  ]
}
```

---

## Error Codes

| Code | Message | Cause |
|------|---------|-------|
| 400 | Bad Request | Invalid parameters |
| 401 | Unauthorized | Invalid credentials |
| 404 | Not Found | Resource doesn't exist |
| 409 | Conflict | Resource already exists |
| 422 | Unprocessable Entity | Invalid data format |
| 429 | Too Many Requests | Rate limited |
| 500 | Internal Server Error | Server error |
| 503 | Service Unavailable | Firebase/Twilio down |

### Error Response Format
```json
{
  "success": false,
  "error": "Invalid blood type",
  "error_code": 422,
  "timestamp": "2024-04-26T10:30:00Z"
}
```

---

## Example Workflows

### Workflow 1: New Donor Registration + SMS Alert

```python
# 1. Create donor
db = FirestoreBackend()
donor = DonorProfile(
    donor_id='DONOR_NEW_001',
    name='New Donor',
    blood_type='O+',
    phone='+919876543210',
    last_donation='2024-04-26',
    donation_count=1,
    location='PUNE',
    is_active=True
)
db.create_donor(donor)

# 2. Search for blood banks needing O+
donors = db.search_donors_by_blood_type('O+')

# 3. Send SMS alert to blood bank
sms.send_match_alert(
    '+919876543210',
    donor['name'],
    'O+',
    1
)
```

### Workflow 2: Blood Match + Notification

```python
# 1. Get inventory status
manager = InventorySyncManager()
inv = manager.get_inventory('SASSOON_HOSPITAL', 'O+')

if inv.quantity > 0:
    # 2. Find compatible donors
    donors = db.search_donors_by_blood_type('O+', limit=1)
    
    # 3. Send SMS to blood bank
    sms.send_match_alert(
        '+919876543210',
        donors[0].name,
        'O+',
        1
    )
    
    # 4. Send push notification
    PushNotificationTrigger.send_topic_notification(
        'blood_alerts',
        'Blood Available',
        f"O+ available at {hospital}"
    )
```

### Workflow 3: Shortage Prediction + Donation Drive

```python
# 1. Check current inventory
current_inv = {
    'O-': 40,
    'O+': 55,
    'A+': 45
}

# 2. Predict shortages
shortages = DonationDriveTrigger.predict_shortage([], current_inv)

# 3. If shortage, trigger drive
if shortages:
    drive = DonationDriveTrigger.trigger_donation_drive(
        shortages,
        'PUNE'
    )
    
    # 4. Send alert SMS
    sms.send_shortage_alert(
        '+919876543210',
        shortages[0],
        current_inv[shortages[0]],
        DonationDriveTrigger.BLOOD_TYPE_THRESHOLD[shortages[0]]
    )
```

### Workflow 4: Offline Sync

```python
# 1. When offline, queue message
OfflineSMSFallback.queue_offline_message(
    '+919876543210',
    'B+ shortage'
)

# 2. When online returns, sync
offline = OfflineSMSFallback()
sms_pipeline = TwilioSMSPipeline(...)
sent = offline.sync_offline_queue(sms_pipeline)
print(f"Synced {sent} messages")
```

---

## Rate Limits

| Service | Limit | Window |
|---------|-------|--------|
| Firestore Reads | 10,000/day | Daily |
| Firestore Writes | 10,000/day | Daily |
| Firebase Realtime | 100 connections | Concurrent |
| Twilio SMS | Variable by plan | Per minute |
| BigQuery | 10,000 jobs/day | Daily |

---

## Dependencies

```python
firebase-admin==6.2.0
twilio==8.10.0
schedule==1.2.0
requests==2.31.0
google-cloud-bigquery==3.13.0
```

---

## Support & Issues

For bugs or integration issues:
1. Check logs: `grep ERROR rakt-setu.log`
2. Verify credentials
3. Check service status
4. Review API contracts above
5. Test in test mode first

---

**Last Updated:** 2024-04-26  
**Maintainer:** RAKT-SETU Team
